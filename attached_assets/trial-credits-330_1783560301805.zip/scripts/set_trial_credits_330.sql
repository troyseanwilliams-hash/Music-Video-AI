-- Trial credits: 330 (was 10).
--
-- The schema change in lib/db/src/schema/beatvision.ts updates the column
-- DEFAULTs; run `pnpm --filter @workspace/db push` to apply those, or run the
-- two ALTERs below manually. Then run the UPDATE to backfill existing trial
-- users who are still on the old default of 10.

-- 1) New rows default to 330 plan credits.
ALTER TABLE credits ALTER COLUMN credits_remaining SET DEFAULT 330;
ALTER TABLE credits ALTER COLUMN subscription_credits SET DEFAULT 330;

-- 2) Backfill: bump anyone still on the old 10-credit trial default up to 330.
--    Restricted to the untouched default (10 remaining, no purchased top-up) so
--    it never disturbs paying/top-up customers who happen to be near 10.
UPDATE credits
SET subscription_credits = 330,
    credits_remaining = 330,
    updated_at = now()
WHERE credits_remaining = 10
  AND topup_credits = 0;
