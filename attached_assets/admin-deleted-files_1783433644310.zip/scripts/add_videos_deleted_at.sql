-- Soft-delete support for videos.
-- Preferred: run `pnpm --filter @workspace/db push` (drizzle-kit) to apply the
-- schema change in lib/db/src/schema/beatvision.ts. This file is the equivalent
-- raw SQL if you apply migrations manually instead.

ALTER TABLE videos ADD COLUMN IF NOT EXISTS deleted_at timestamptz;

-- Optional: speeds up the admin "deleted files" listing and the auto-purge sweep.
CREATE INDEX IF NOT EXISTS videos_deleted_at_idx ON videos (deleted_at);
