import { useEffect, useMemo, useState } from "react";
import { useLocation, Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { AUTH_QUERY_KEY, useAuth } from "@/hooks/useAuth";
import {
  useListBillingPlans,
  useGetBillingSubscription,
  createBillingCheckout,
  createBillingPortalSession,
  getGetBillingSubscriptionQueryKey,
  getGetCreditsQueryKey,
  getGetDashboardStatsQueryKey,
  type BillingSubscriptionResponse,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import {
  Check,
  Loader2,
  Zap,
  Crown,
  Sparkles,
  CreditCard,
  ArrowLeft,
  ChevronDown,
} from "lucide-react";

type Interval = "month" | "year";

function formatPrice(amount: number, currency: string): string {
  const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currency.toUpperCase(),
    minimumFractionDigits: amount % 100 === 0 ? 0 : 2,
  });
  return formatter.format(amount / 100);
}

function getQueryParam(name: string): string | null {
  if (typeof window === "undefined") return null;
  return new URLSearchParams(window.location.search).get(name);
}

const TIER_ICONS: Record<string, typeof Zap> = {
  starter: Zap,
  pro: Sparkles,
  studio: Crown,
};

export default function Pricing() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, isLoading: isAuthLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [interval, setInterval] = useState<Interval>("month");
  const [busyPriceId, setBusyPriceId] = useState<string | null>(null);
  const [portalBusy, setPortalBusy] = useState(false);

  const { data: plans, isLoading: plansLoading } = useListBillingPlans();
  const { data: subscription } = useGetBillingSubscription({
    query: { enabled: isAuthenticated },
  });

  useEffect(() => {
    const status = getQueryParam("status");
    if (status === "success") {
      toast({
        title: "Payment successful",
        description: "Thanks! Updating your credits…",
      });
      window.history.replaceState({}, "", window.location.pathname);

      const subKey = getGetBillingSubscriptionQueryKey();
      const creditsKey = getGetCreditsQueryKey();
      const statsKey = getGetDashboardStatsQueryKey();

      const initialSub =
        queryClient.getQueryData<BillingSubscriptionResponse>(subKey);
      const initialCredits = initialSub?.creditsRemaining ?? 0;
      const initialActive = initialSub?.subscriptionStatus === "active";

      const invalidateAll = () => {
        queryClient.invalidateQueries({ queryKey: subKey });
        queryClient.invalidateQueries({ queryKey: creditsKey });
        queryClient.invalidateQueries({ queryKey: statsKey });
        queryClient.invalidateQueries({ queryKey: AUTH_QUERY_KEY });
      };

      invalidateAll();

      const startedAt = Date.now();
      const intervalId = window.setInterval(() => {
        const elapsed = Date.now() - startedAt;
        const sub =
          queryClient.getQueryData<BillingSubscriptionResponse>(subKey);
        const creditsIncreased =
          (sub?.creditsRemaining ?? 0) > initialCredits;
        const becameActive =
          !initialActive && sub?.subscriptionStatus === "active";

        if (creditsIncreased || becameActive || elapsed >= 10000) {
          window.clearInterval(intervalId);
          return;
        }
        invalidateAll();
      }, 1500);

      return () => window.clearInterval(intervalId);
    } else if (status === "cancelled") {
      toast({
        title: "Checkout cancelled",
        description: "No charge was made.",
      });
      window.history.replaceState({}, "", window.location.pathname);
    }
    return undefined;
  }, [toast, queryClient]);

  const subscriptions = plans?.subscriptions ?? [];
  const topups = plans?.topups ?? [];

  const hasYearly = useMemo(
    () =>
      subscriptions.some((p) => p.prices.some((pr) => pr.interval === "year")),
    [subscriptions],
  );

  const handleSubscribe = async (priceId: string) => {
    if (!isAuthenticated) {
      setLocation("/login");
      return;
    }
    setBusyPriceId(priceId);
    try {
      const result = await createBillingCheckout({ priceId });
      window.location.href = result.url;
    } catch (err) {
      toast({
        title: "Checkout failed",
        description:
          err instanceof Error ? err.message : "Could not start checkout.",
        variant: "destructive",
      });
      setBusyPriceId(null);
    }
  };

  const handleOpenPortal = async () => {
    setPortalBusy(true);
    try {
      const result = await createBillingPortalSession({});
      window.location.href = result.url;
    } catch (err) {
      toast({
        title: "Could not open billing portal",
        description:
          err instanceof Error ? err.message : "Please try again later.",
        variant: "destructive",
      });
      setPortalBusy(false);
    }
  };

  if (isAuthLoading || plansLoading) {
    return (
      <div className="flex items-center justify-center py-32">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="mb-6 flex items-center justify-between gap-4">
        <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        {isAuthenticated && subscription?.hasStripeCustomer && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleOpenPortal}
            disabled={portalBusy}
            data-testid="button-billing-portal"
          >
            {portalBusy ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <CreditCard className="mr-2 h-4 w-4" />
            )}
            Manage Billing
          </Button>
        )}
      </div>

      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
          Choose your plan
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Credits are consumed per video generated. A 5-second clip costs{" "}
          <strong className="text-foreground">165 credits</strong>, a
          10-second clip costs{" "}
          <strong className="text-foreground">330 credits</strong>. Plan
          credits reset each cycle — top-up credits never expire.
        </p>
        {isAuthenticated && subscription && (
          <div
            className="mt-4 inline-flex items-center gap-2 rounded-full border border-border/50 bg-secondary/40 px-4 py-2 text-sm"
            data-testid="pricing-credits-summary"
          >
            <Zap className="h-4 w-4 text-primary" />
            <span>
              You have <strong>{subscription.creditsRemaining}</strong> credit
              {subscription.creditsRemaining === 1 ? "" : "s"} remaining
            </span>
            {(subscription.subscriptionCredits > 0 ||
              subscription.topupCredits > 0) && (
              <span className="text-muted-foreground">
                · {subscription.subscriptionCredits} plan +{" "}
                {subscription.topupCredits} top-up
              </span>
            )}
            {subscription.planName && (
              <span className="text-muted-foreground">
                · {subscription.planName}
              </span>
            )}
          </div>
        )}
      </div>

      {hasYearly && (
        <div className="flex items-center justify-center mb-10">
          <div className="inline-flex rounded-lg border border-border bg-card/50 p-1">
            <button
              type="button"
              onClick={() => setInterval("month")}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${
                interval === "month"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              data-testid="button-interval-monthly"
            >
              Monthly
            </button>
            <button
              type="button"
              onClick={() => setInterval("year")}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${
                interval === "year"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              data-testid="button-interval-yearly"
            >
              Yearly <span className="text-xs opacity-70">(save ~17%)</span>
            </button>
          </div>
        </div>
      )}

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        {subscriptions.map((plan) => {
          const price =
            plan.prices.find((p) => p.interval === interval) ??
            plan.prices.find((p) => p.interval === "month") ??
            plan.prices[0];
          if (!price) return null;
          const Icon = TIER_ICONS[plan.name.toLowerCase()] ?? Sparkles;
          const isCurrent =
            subscription?.priceLookupKey &&
            price.lookupKey === subscription.priceLookupKey;

          return (
            <Card
              key={plan.id}
              className={`relative bg-card/50 border ${
                plan.popular
                  ? "border-primary/60 shadow-glow"
                  : "border-card-border"
              }`}
              data-testid={`card-plan-${plan.name.toLowerCase()}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-electric text-xs font-semibold text-white shadow-glow">
                  Most popular
                </div>
              )}
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                </div>
                <p className="text-sm text-muted-foreground">
                  {plan.description}
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-bold">
                      {formatPrice(price.unitAmount, price.currency)}
                    </span>
                    <span className="text-muted-foreground">
                      / {price.interval === "year" ? "yr" : "mo"}
                    </span>
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    {price.credits} credits per{" "}
                    {price.interval === "year" ? "year" : "month"}
                  </div>
                </div>

                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span>
                      {price.credits.toLocaleString()} credits per{" "}
                      {price.interval === "year" ? "year" : "month"}{" "}
                      <span className="text-muted-foreground">
                        (~{Math.floor(price.credits / 165)} × 5s or{" "}
                        {Math.floor(price.credits / 330)} × 10s clips)
                      </span>
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span>Beat-synced AI music videos</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span>Full HD downloads</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span>Cancel or change plans anytime</span>
                  </li>
                </ul>

                <Button
                  className={`w-full ${
                    plan.popular
                      ? "bg-gradient-electric text-white shadow-glow"
                      : ""
                  }`}
                  variant={plan.popular ? "default" : "outline"}
                  disabled={busyPriceId === price.id || Boolean(isCurrent)}
                  onClick={() => handleSubscribe(price.id)}
                  data-testid={`button-subscribe-${plan.name.toLowerCase()}`}
                >
                  {busyPriceId === price.id ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : null}
                  {isCurrent
                    ? "Current plan"
                    : isAuthenticated
                      ? "Subscribe"
                      : "Sign in to subscribe"}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </section>

      {topups.length > 0 && (
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold mb-2">Credit packs</h2>
            <p className="text-muted-foreground">
              One-time purchase · credits never expire · bigger packs = lower cost per video
            </p>
            <div className="inline-flex items-center gap-2 mt-4 px-4 py-2 rounded-full border border-primary/40 bg-primary/10 text-sm font-medium">
              <span className="text-primary font-semibold">15% off your first pack</span>
              <span className="text-muted-foreground">— use code</span>
              <code className="px-2 py-0.5 rounded bg-primary/20 text-primary font-mono font-bold tracking-wider">FIRST15</code>
              <span className="text-muted-foreground text-xs">at checkout</span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {topups.map((plan) => {
              const price = plan.prices[0];
              if (!price) return null;

              // Face value: $0.02/credit = 2 cents/credit
              const faceValueCents = price.credits * 2;
              const savingsPct = faceValueCents > 0
                ? Math.round((1 - price.unitAmount / faceValueCents) * 100)
                : 0;
              const perCreditCents = price.unitAmount / 100 / price.credits;
              const estClips = Math.floor(price.credits / 330);

              return (
                <Card
                  key={plan.id}
                  className={`relative bg-card/30 border ${plan.popular ? "border-primary/60 shadow-glow" : "border-card-border"}`}
                  data-testid={`card-topup-${price.credits}`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-electric text-xs font-semibold text-white shadow-glow">
                      Best value
                    </div>
                  )}
                  {savingsPct > 0 && !plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-secondary border border-border text-xs font-semibold text-foreground">
                      Save {savingsPct}%
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle className="text-xl">
                      {price.credits.toLocaleString()} credits
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      ≈ {estClips} × 10s clips · never expires
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="text-3xl font-bold">
                        {formatPrice(price.unitAmount, price.currency)}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-sm text-muted-foreground">
                          ${perCreditCents.toFixed(3).replace(/0+$/, "").replace(/\.$/, "")} / credit
                        </span>
                        {savingsPct > 0 && (
                          <span className="text-xs font-medium text-primary">
                            {savingsPct}% off
                          </span>
                        )}
                      </div>
                    </div>
                    <Button
                      className={`w-full ${plan.popular ? "bg-gradient-electric text-white shadow-glow" : ""}`}
                      variant={plan.popular ? "default" : "outline"}
                      disabled={busyPriceId === price.id}
                      onClick={() => handleSubscribe(price.id)}
                      data-testid={`button-topup-${price.credits}`}
                    >
                      {busyPriceId === price.id ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : null}
                      Buy now
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>
      )}

      <div className="text-center text-sm text-muted-foreground mb-16">
        Need a custom plan?{" "}
        <Link href="/support" className="text-primary hover:underline">
          Get in touch
        </Link>
        .
      </div>

      {/* FAQ */}
      <section className="border-t border-border/30 pt-14">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8">Billing FAQ</h2>
          <div className="space-y-4 text-sm">
            {[
              {
                q: "What counts as a credit?",
                a: "One 5-second clip costs 165 credits; one 10-second clip costs 330 credits. Longer videos chain multiple clips together.",
              },
              {
                q: "Do plan credits roll over?",
                a: "No — plan credits reset at the start of each billing cycle. Top-up packs are separate and never expire.",
              },
              {
                q: "Can I switch plans?",
                a: "Yes. Upgrade or downgrade any time. Changes take effect at the next billing cycle; unused credits stay until reset.",
              },
              {
                q: "What payment methods are accepted?",
                a: "All major credit and debit cards via Stripe. Invoices available on request for annual plans.",
              },
              {
                q: "Is there a free trial?",
                a: "New accounts start with a limited free trial. Sign up to see your trial credits on the dashboard.",
              },
            ].map(({ q, a }) => (
              <div key={q} className="rounded-xl border border-border/50 overflow-hidden">
                <details className="group">
                  <summary className="flex items-center justify-between px-5 py-4 bg-card/40 hover:bg-card/70 transition-colors cursor-pointer list-none">
                    <span className="font-medium">{q}</span>
                    <ChevronDown className="h-4 w-4 text-muted-foreground shrink-0 ml-3 group-open:rotate-180 transition-transform" />
                  </summary>
                  <div className="px-5 py-4 text-muted-foreground leading-relaxed border-t border-border/30 bg-card/20">
                    {a}
                  </div>
                </details>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
